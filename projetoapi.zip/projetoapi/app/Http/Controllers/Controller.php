<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function Success(){

        return response ()->json([

            "success"=>true,
            "message"=>"Débito Cadastrado com Sucesso",
           
        ]);
    }
    public function Error(){

        return response ()->json([

            "success"=>false,
            "message"=>"Falha ao Cadastrar Débito",
           
        ]);
    }
}
