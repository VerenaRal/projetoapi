<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PessoaController extends Controller
{
    public function index(){

      $data = [

        "titulo"=>"Projeto Piloto de API",
        "conteudo"=>"Construção de Teste de Simulação de Crédito",
        "autor"=>"Verena RAL",
        "ano"=>2020,
         ];
         return response()->json($data);
    }
    public function teste(Request $request){ 
        $data = $request->all();     //         ou public function teste(Request $request){
        return response()->json($data['usuário']);

    }
    
}
