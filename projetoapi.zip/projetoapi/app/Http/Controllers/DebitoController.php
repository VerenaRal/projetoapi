<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Debito;

use function GuzzleHttp\Promise\all;

class DebitoController extends Controller
{
public function readAll(){

    Debito::all();
}
public function update($cpfcnpj, Request $request){


    $data = ($request->$cpfcnpj());
  
    $data->update();
   
}
public function delete($cpfcnpj){

    $debito = Debito::find($cpfcnpj);
    if(!isset($debito)){
      return  $this->SendError("Débito não encontrado", 404);
    }
    $debito ->delete();

}

    public function create(Request $request){

        $data = ($request->all());
        $d = Debito::create($data);
     dd($d);

     if ($d){

        return $this->Success();
       
        }else{
            return $this->Error();
           

           
    }
}
}
